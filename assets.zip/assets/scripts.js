const copyright = document.getElementById("copyright");
const date = new Date();
copyright.innerHTML = `<i class="fa-solid fa-copyright"></i> Copyright  ${date.getFullYear()}  Kieni Edojah`;
